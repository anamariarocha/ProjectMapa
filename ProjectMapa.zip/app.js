/* Javascript - app.js */

const app = {
    init: function() {
        //Inicializa o mapa
        this.mapa = L.map("mapa");
        //Define o modelo de mapa
        L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        //L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
        //L.tileLayer("https://{s}.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png", {
        //L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}", {
            maxZoom: 18,
            minZoom: 15
        }).addTo(this.mapa);
        //Configura a geolocalização
        this.mapa.locate({
            setView: true,
            watch: true,
            enableHighAccuracy: true
        });
        //Cria o marcador do jogador
        player.init();
        player.marker.addTo(this.mapa);
        //Configura o evento para mover o jogador
        this.mapa.on("locationfound", (evt)=>this.onLocationFound(evt));
        
        player.selectModel();
    },
    onLocationFound: function(evt) {
        player.marker.setLatLng(evt.latlng);
    }
};

app.init();
