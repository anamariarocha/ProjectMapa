/* Javascript - player.js */
const player = {
    init: function() {
        this.icon = new L.divIcon({
            className: "player",
            html: "<span id='playerIcon'>&#x1F574</span>"
        });
        this.marker = new L.Marker([0, 0], {
            icon: this.icon
        });
    },
    setIcon: function(icon){
        document.querySelector("#playerIcon").innerHTML = icon;
    },
    selectModel: function() {
        let skinTones = ["","&#x1F3FB;","&#x1F3FC;","&#x1F3FD;","&#x1F3FE;","&#x1F3FF;"];
        let genders = ["","&#x200D;&#x2640;&#xFE0F;","&#x200D;&#x2642;&#xFE0F;"];
        let models = ["&#x1F64E;"];

        let dialog = document.createElement("dialog");
        for(let tone of skinTones) {
            for(let gender of genders) {
                let button = document.createElement("button");
                button.innerHTML = `${models[0]}${tone}${gender}`;
                button.onclick = () => {
                    this.setIcon(`${models[0]}${tone}${gender}`);
                    dialog.close();
                };
                dialog.appendChild(button);
            }
            dialog.appendChild(document.createElement("br"));
        }
        
        dialog.onclose = () => document.body.removeChild(dialog);
        document.body.appendChild(dialog);
        dialog.showModal();
    },
};